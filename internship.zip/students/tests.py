from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import ClassRoom, ClassSubject, Department, Grade, Student, Subject


class BasicTests(TestCase):
    def setUp(self):
        User.objects.create_user('tester', password='pass12345')
        dept = Department.objects.create(name='CS', code='CS')
        self.room = ClassRoom.objects.create(
            name='Class 10', section='A', department=dept, academic_year='2026-27')
        u = User.objects.create_user('s1', password='x', first_name='Asha', last_name='K')
        self.student = Student.objects.create(
            user=u, roll_number='1', admission_number='A1', date_of_birth='2010-01-01',
            gender='F', address='Street', phone='1', parent_name='P', parent_phone='2',
            class_room=self.room)

    def test_login_required(self):
        r = self.client.get(reverse('students:dashboard'))
        self.assertEqual(r.status_code, 302)

    def test_pages_load(self):
        self.client.login(username='tester', password='pass12345')
        for name in ['dashboard', 'student_list', 'attendance_mark',
                     'fee_list', 'class_stats', 'timetable', 'student_create']:
            r = self.client.get(reverse('students:' + name))
            self.assertEqual(r.status_code, 200, name)

    def test_detail_and_report(self):
        self.client.login(username='tester', password='pass12345')
        r = self.client.get(reverse('students:student_detail', args=[self.student.pk]))
        self.assertEqual(r.status_code, 200)
        r = self.client.get(reverse('students:report_card_pdf', args=[self.student.pk]))
        self.assertEqual(r['Content-Type'], 'application/pdf')

    def test_grade_calculation(self):
        subject = Subject.objects.create(name='Maths', code='M1', department=self.room.department)
        cs = ClassSubject.objects.create(class_room=self.room, subject=subject)
        g = Grade.objects.create(student=self.student, class_subject=cs,
                                 exam_name='Mid', marks_obtained=45, total_marks=50)
        self.assertEqual(g.grade, 'A+')

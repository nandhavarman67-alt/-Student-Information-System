from django.urls import path
from . import views

app_name = 'students'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('list/', views.student_list, name='student_list'),
    path('attendance/', views.attendance_mark, name='attendance_mark'),
    path('add/', views.student_create, name='student_create'),
    path('export/excel/', views.students_export_excel, name='export_excel'),
    path('fees/', views.fee_list, name='fee_list'),
    path('fees/add/', views.fee_add, name='fee_add'),
    path('fees/<int:pk>/paid/', views.fee_mark_paid, name='fee_mark_paid'),
    path('stats/', views.class_stats, name='class_stats'),
    path('timetable/', views.timetable, name='timetable'),
    path('<int:pk>/', views.student_detail, name='student_detail'),
    path('<int:pk>/edit/', views.student_edit, name='student_edit'),
    path('<int:pk>/report/', views.report_card_pdf, name='report_card_pdf'),
]

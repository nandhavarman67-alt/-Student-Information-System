from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from django.db.models import Q, Sum
from .models import Student, ClassRoom, Department, Fee


@login_required
def dashboard(request):
    context = {
        'student_count': Student.objects.filter(is_active=True).count(),
        'class_count': ClassRoom.objects.count(),
        'department_count': Department.objects.count(),
        'pending_fees': Fee.objects.filter(is_paid=False).aggregate(total=Sum('amount'))['total'] or 0,
        'recent_students': Student.objects.select_related('user', 'class_room').order_by('-created_at')[:5],
    }
    return render(request, 'students/dashboard.html', context)


@login_required
def student_list(request):
    students = Student.objects.select_related('user', 'class_room').order_by('roll_number')
    q = request.GET.get('q', '')
    class_id = request.GET.get('class_room', '')

    if q:
        students = students.filter(
            Q(user__first_name__icontains=q) |
            Q(user__last_name__icontains=q) |
            Q(roll_number__icontains=q)
        )
    if class_id:
        students = students.filter(class_room_id=class_id)

    context = {
        'students': students,
        'classrooms': ClassRoom.objects.all(),
        'q': q,
        'class_id': class_id,
    }
    return render(request, 'students/student_list.html', context)


@login_required
def student_detail(request, pk):
    student = get_object_or_404(Student, pk=pk)
    attendances = student.attendances.select_related('class_subject__subject')[:20]
    total = student.attendances.count()
    present = student.attendances.filter(is_present=True).count()
    attendance_percent = round(present / total * 100, 1) if total else 0

    context = {
        'student': student,
        'attendances': attendances,
        'attendance_percent': attendance_percent,
        'grades': student.grades.select_related('class_subject__subject').order_by('-created_at'),
        'fees': student.fees.order_by('-due_date'),
    }
    return render(request, 'students/student_detail.html', context)



from datetime import date
from django.contrib import messages
from django.shortcuts import redirect
from .models import ClassSubject, Attendance


@login_required
def attendance_mark(request):
    class_subjects = ClassSubject.objects.select_related('class_room', 'subject')
    data = request.POST if request.method == 'POST' else request.GET
    cs_id = data.get('class_subject')
    try:
        day = date.fromisoformat(data.get('date', ''))
    except ValueError:
        day = date.today()

    selected = None
    students = []
    present_ids = set()

    if cs_id:
        selected = get_object_or_404(ClassSubject, pk=cs_id)
        students = list(
            Student.objects.filter(class_room=selected.class_room, is_active=True)
            .select_related('user').order_by('roll_number')
        )
        if request.method == 'POST':
            present = set(request.POST.getlist('present'))
            for s in students:
                Attendance.objects.update_or_create(
                    student=s, class_subject=selected, date=day,
                    defaults={'is_present': str(s.id) in present},
                )
            messages.success(request, f'Attendance saved for {day}.')
            return redirect(f'{request.path}?class_subject={selected.id}&date={day}')

        records = Attendance.objects.filter(class_subject=selected, date=day)
        if records.exists():
            present_ids = set(records.filter(is_present=True).values_list('student_id', flat=True))
        else:
            present_ids = {s.id for s in students}

    return render(request, 'students/attendance_mark.html', {
        'class_subjects': class_subjects,
        'selected': selected,
        'students': students,
        'present_ids': present_ids,
        'date_value': day.isoformat(),
    })


from .forms import StudentForm


@login_required
def student_create(request):
    form = StudentForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        student = form.save()
        messages.success(request, 'Student added.')
        return redirect('students:student_detail', pk=student.pk)
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Add Student'})


@login_required
def student_edit(request, pk):
    student = get_object_or_404(Student, pk=pk)
    form = StudentForm(request.POST or None, instance=student)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Student updated.')
        return redirect('students:student_detail', pk=student.pk)
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Edit Student'})


import io
from xml.sax.saxutils import escape
from django.http import HttpResponse
from django.db.models import Avg
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from openpyxl import Workbook


def _attendance_percent(student):
    total = student.attendances.count()
    present = student.attendances.filter(is_present=True).count()
    return round(present / total * 100, 1) if total else 0


@login_required
def report_card_pdf(request, pk):
    student = get_object_or_404(Student, pk=pk)
    grades = student.grades.select_related('class_subject__subject').order_by(
        'class_subject__subject__name', 'exam_name')
    avg = grades.aggregate(a=Avg('percentage'))['a']
    avg_text = f'{round(avg, 1)}%' if avg is not None else 'N/A'
    name = f'{student.user.first_name} {student.user.last_name}'.strip()

    styles = getSampleStyleSheet()
    items = [
        Paragraph('Report Card', styles['Title']),
        Paragraph(f'<b>Name:</b> {escape(name)}', styles['Normal']),
        Paragraph(f'<b>Roll No:</b> {escape(student.roll_number)}', styles['Normal']),
        Paragraph(f'<b>Class:</b> {escape(str(student.class_room))}', styles['Normal']),
        Paragraph(f'<b>Attendance:</b> {_attendance_percent(student)}%', styles['Normal']),
        Paragraph(f'<b>Average:</b> {avg_text}', styles['Normal']),
        Spacer(1, 20),
    ]

    data = [['Subject', 'Exam', 'Marks', '%', 'Grade']]
    for g in grades:
        data.append([
            str(g.class_subject.subject), g.exam_name,
            f'{g.marks_obtained} / {g.total_marks}', f'{g.percentage}', g.grade,
        ])
    if len(data) == 1:
        data.append(['No grades yet', '', '', '', ''])

    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c3e50')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f4f6f8')]),
    ]))
    items.append(table)

    buffer = io.BytesIO()
    SimpleDocTemplate(buffer, pagesize=A4).build(items)
    response = HttpResponse(buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="report_card_{student.roll_number}.pdf"'
    return response


@login_required
def students_export_excel(request):
    wb = Workbook()
    ws = wb.active
    ws.title = 'Students'
    ws.append(['Roll No', 'Name', 'Class', 'Parent', 'Parent Phone', 'Attendance %', 'Average %'])
    students = Student.objects.select_related('user', 'class_room').order_by('roll_number')
    for s in students:
        avg = s.grades.aggregate(a=Avg('percentage'))['a']
        ws.append([
            s.roll_number,
            f'{s.user.first_name} {s.user.last_name}'.strip(),
            str(s.class_room),
            s.parent_name,
            s.parent_phone,
            _attendance_percent(s),
            round(float(avg), 1) if avg is not None else '',
        ])
    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="students.xlsx"'
    wb.save(response)
    return response


from django.views.decorators.http import require_POST
from .forms import FeeForm


@login_required
def fee_list(request):
    status = request.GET.get('status', '')
    fees = Fee.objects.select_related('student__user', 'student__class_room').order_by('is_paid', 'due_date')
    if status == 'pending':
        fees = fees.filter(is_paid=False)
    elif status == 'paid':
        fees = fees.filter(is_paid=True)

    context = {
        'fees': fees,
        'status': status,
        'pending_total': Fee.objects.filter(is_paid=False).aggregate(t=Sum('amount'))['t'] or 0,
        'paid_total': Fee.objects.filter(is_paid=True).aggregate(t=Sum('amount'))['t'] or 0,
        'today': date.today(),
    }
    return render(request, 'students/fee_list.html', context)


@login_required
def fee_add(request):
    initial = {}
    if request.GET.get('student'):
        initial['student'] = request.GET['student']
    form = FeeForm(request.POST or None, initial=initial)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Fee added.')
        return redirect('students:fee_list')
    return render(request, 'students/student_form.html', {'form': form, 'title': 'Add Fee'})


@login_required
@require_POST
def fee_mark_paid(request, pk):
    fee = get_object_or_404(Fee, pk=pk)
    if not fee.is_paid:
        fee.is_paid = True
        fee.paid_date = date.today()
        if not fee.receipt_number:
            fee.receipt_number = f'R{fee.pk:05d}'
        fee.save()
        messages.success(request, f'Fee marked as paid. Receipt {fee.receipt_number}.')
    return redirect('students:fee_list')


from django.db.models import Count
from .models import Grade


@login_required
def class_stats(request):
    rows = []
    for c in ClassRoom.objects.select_related('department').order_by('name', 'section'):
        att = Attendance.objects.filter(student__class_room=c)
        total = att.count()
        present = att.filter(is_present=True).count()
        avg = Grade.objects.filter(student__class_room=c).aggregate(a=Avg('percentage'))['a']
        rows.append({
            'room': c,
            'students': Student.objects.filter(class_room=c, is_active=True).count(),
            'attendance': round(present / total * 100, 1) if total else None,
            'average': round(float(avg), 1) if avg is not None else None,
        })

    low = []
    for s in Student.objects.filter(is_active=True).select_related('user', 'class_room'):
        total = s.attendances.count()
        if total:
            pct = round(s.attendances.filter(is_present=True).count() / total * 100, 1)
            if pct < 75:
                low.append({'student': s, 'percent': pct})
    low.sort(key=lambda x: x['percent'])

    return render(request, 'students/class_stats.html', {'rows': rows, 'low': low})


from .models import Timetable


@login_required
def timetable(request):
    classrooms = ClassRoom.objects.order_by('name', 'section')
    cid = request.GET.get('class_room', '')
    room = None
    grid = []
    days = Timetable.DAY_CHOICES
    if cid:
        room = get_object_or_404(ClassRoom, pk=cid)
        entries = Timetable.objects.filter(class_room=room).select_related(
            'class_subject__subject', 'class_subject__teacher')
        lookup = {(e.day, e.period): e for e in entries}
        max_period = max([e.period for e in entries], default=0)
        for p in range(1, max_period + 1):
            grid.append({'period': p, 'cells': [lookup.get((d[0], p)) for d in days]})
    return render(request, 'students/timetable.html', {
        'classrooms': classrooms, 'room': room, 'grid': grid, 'days': days, 'class_id': cid,
    })
